#!/usr/bin/env python3
"""Install payload from an extracted VIBS/VERIFIED ZIP. Dry-run by default."""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path, help="Git checkout path (INP recommended)")
    parser.add_argument("--apply", action="store_true", help="Actually copy; otherwise only show plan")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    payload = Path(__file__).resolve().parent / "payload"
    if not (repo / ".git").exists():
        print("BLOCK: Target is not a Git checkout: " + str(repo), file=sys.stderr)
        return 2
    if not payload.is_dir():
        print("BLOCK: ZIP payload missing", file=sys.stderr)
        return 2
    source_files = sorted(p for p in payload.rglob("*") if p.is_file())
    conflicts = []
    planned = []
    for source in source_files:
        rel = source.relative_to(payload)
        if ".." in rel.parts or rel.is_absolute():
            print("BLOCK: Unsafe payload path", file=sys.stderr)
            return 2
        target = repo / rel
        resolved = target.resolve()
        try:
            resolved.relative_to(repo)
        except ValueError:
            print("BLOCK: Path escapes repository: " + str(rel), file=sys.stderr)
            return 2
        if target.exists() or target.is_symlink():
            conflicts.append(str(rel))
        planned.append((source, target, rel))
    print("Repository:", repo)
    print("Files:", len(planned))
    for _, _, rel in planned:
        print("  ADD", rel)
    if conflicts:
        print("BLOCK: Existing files will never be overwritten:", ", ".join(conflicts), file=sys.stderr)
        return 2
    if not args.apply:
        print("DRY RUN. To install, repeat with --apply.")
        return 0
    created = []
    try:
        for source, target, _ in planned:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as out, source.open("rb") as inp:
                shutil.copyfileobj(inp, out)
            created.append(target)
    except Exception:
        for path in reversed(created):
            path.unlink(missing_ok=True)
        raise
    print("Installed. Review with git status / git diff before committing.")
    print("No application text, governance policy or partner data changed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
