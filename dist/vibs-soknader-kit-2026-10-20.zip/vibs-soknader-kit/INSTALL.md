# VIBS / VERIFIED søknadsteam – installasjon

Dette ZIP-arkivet er laget for repoet https://github.com/Luaze1985/INP og kan brukes på en annen Git-checkout etter vurdering. Pakken har ingen eksterne Python-avhengigheter og overskriver ingen eksisterende filer.

1. Last ned ZIP og pakk det ut.
2. Gå inn i mappen vibs-soknader-kit.
3. Kontroller innholdet. Kjør først:
   
       python install.py --repo /sti/til/INP

4. Installer bare når listen er godkjent:

       python install.py --repo /sti/til/INP --apply

5. Se git status, gjennomgå diff og test:

       python tools/soknadsteam.py inspect --repo /sti/til/INP
       python -m unittest discover -s tests -p 'test_soknadsteam.py'

6. Kjør en review med eksplisitt valgt søknadsfil, se docs/agents/soknadsteam/README.md.

Alternativ: den tilhørende GitHub-draft-PR-en viser samme payload som diff. Merge er ikke gjort. Hvis du bruker PR-en, ikke installer ZIP i tillegg; installasjonsprogrammet stopper ved filkonflikt.

Pakken oppretter ikke en automatisk LLM-agentkjøring. Den gir rolleprompter, filkontrakter, kontroll og rapportering. Deep Research-sluttrapporten er ikke importert. Offisielle tilskuddsvilkår og partnerstatus er ikke bekreftet av denne pakken.
